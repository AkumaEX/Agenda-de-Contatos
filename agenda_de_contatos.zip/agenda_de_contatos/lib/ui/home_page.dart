import 'package:flutter/material.dart';
import 'package:agenda_de_contatos/helpers/contact_helper.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ContactHelper helper = ContactHelper();

  @override
  Widget build(BuildContext context) {
    return Container();
  }

  @override
  void initState() {
    super.initState();

    Contact c = Contact.fromMap({
      'nome': 'Julio',
      'email': 'akumaex@gmail.com',
      'phone': '123456',
      'img': 'abc'
    });
    helper.saveContact(c);

    helper.getContact(c.id).then((contact) {
      print(contact);
    });
  }
}
